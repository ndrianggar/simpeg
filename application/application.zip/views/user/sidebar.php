<div class="col-md-3 left_col">
	<div class="left_col scroll-view">
		<div class="navbar nav_title" style="border: 0;">
			<a id="logo_site" href="<?=base_url()?>" class="site_title">
				<img src="<?=base_url()?>assets/images/logo2.gif" width="45px" height="45px">
				<span> Simpeg Polines</span>
			</a>
		</div>
		<div class="clearfix"></div>

		<!-- sidebar menu -->
		<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
			<div class="menu_section">
				<ul class="nav side-menu">
					<li>
						<a href="<?=base_url()?>pegawai"><i class="fa fa-dashboard"></i>Profil Pegawai</a>
					</li>
					<li>
						<a href="<?=base_url()?>pegawai/user"><i class="fa fa-user"></i>Data Saya</a>
					</li>
					<li>
						<a href="<?=base_url()?>setting"><i class="fa fa-key"></i>Setting User</a>
					</li>
					<!-- <li>
						<a href="#"><i class="fa fa-comments-o"></i>Notice</a>
					</li>
					<li>
						<a href="#"><i class="fa fa-comments-o"></i>History</a>
					</li> -->
				</ul>
			</div>
		</div>
		<!-- /sidebar menu -->

	</div>
</div>