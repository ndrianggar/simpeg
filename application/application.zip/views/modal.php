<!-- modal tambah/edit -->
<div class="modal fade" id="modal-detail">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<div class="modal-title">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<span><h2>Tambah Data Pegawai</h2></span>
				</div>
			</div>
			<div class="modal-body scroll_modal">
			</div>
			<div class="modal-footer">
				<div class="navbar-right">
					<div class="btn-group">
						<button type="button" id="btn-batal" class="btn btn-warning" data-dismiss="modal">Batal</button>
						<button type="button" id="btn-simpan" class="btn btn-success">Simpan</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /modal tambah/edit -->