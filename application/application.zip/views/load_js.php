<!-- jQuery -->
<script src="<?=base_url()?>assets/vendors/jquery/dist/jquery.min.js"></script>
<script src="<?=base_url()?>assets/vendors/jquery/dist/jquery.form.js"></script>
<!-- Bootstrap -->
<script src="<?=base_url()?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?=base_url()?>assets/vendors/nprogress/nprogress.js"></script>
<!-- Skycons -->
<script src="<?=base_url()?>assets/vendors/skycons/skycons.js"></script>
<!-- Parsley -->
<script src="<?=base_url()?>assets/vendors/parsleyjs/dist/parsley.min.js"></script>
<!-- Chart.js -->
<script src="<?=base_url()?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="<?=base_url()?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
<!-- DataTable -->
<script src="<?=base_url()?>assets/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?=base_url()?>assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?=base_url()?>assets/build/js/custom.min.js"></script>
<script src="<?=base_url()?>assets/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?=base_url()?>assets/vendors/select-master/dist/js/bootstrap-select.js"></script>
<!-- bootstrap-datepicker -->
<script src="<?=base_url()?>assets/vendors/vitalets-datepicker/js/bootstrap-datepicker.js"></script>

<!-- Custom JQuery by : Masruh Choeroni -->
<script src="<?=base_url()?>assets/my_jquery/choeroni.js" type="text/javascript"></script>