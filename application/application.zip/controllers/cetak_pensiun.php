<?php
foreach ($data_pensiun as $row) { 
$content	=
'<style type="text/css">
	.tabel {border-collapse:collapse;}
	.tabel th {padding:8px 5px;}
	.tabel td {padding:8px 5px;}
</style>';

	$content 	.= '<page style="font-size: 8px" orientation="portrait" format="A4" >
						<h4 align="center"><u><b>DAFTAR SUSUNAN KELUARGA</b></u></h4>
						';
	$content	.= 
				'
				<div style="margin-left:50px; margin-top:20px; font-size:14px;">
					<p>Yang bertanda tangan dibawah ini :</p>
				</div>
				<br>
				<div style="margin-left:50px; font-size:12px; margin-top:10px;">
					<table>
						<tr>
							<td>Nama</td>
							<td>:</td>
							<td>Syamsudin Suryadi</td>
						</tr>
						<tr>
							<td>NIP</td>
							<td>:</td>
							<td>19600121 198902 1 001</td>
						</tr>
						<tr>
							<td>Nomor Seri KARPEG</td>
							<td>:</td>
							<td>E 725421</td>
						</tr>
						<tr>
							<td>Tempat / Tgl. Lahir</td>
							<td>:</td>
							<td>Semarang, 21 Januari 1960</td>
						</tr>
						<tr>
							<td>Pangkat / Gol. dan Pangkat</td>
							<td>:</td>
							<td>Penata, III/c</td>
						</tr>
						<tr>
							<td>Jabatan</td>
							<td>:</td>
							<td>Pranata Labotatorium Pendidikan Penyelia</td>
						</tr>
						<tr>
							<td>Unit Organisasi</td>
							<td>:</td>
							<td>Politeknik Negeri Semarang</td>
						</tr>
						<tr>
							<td>Alamat Rumah Sekarang</td>
							<td>:</td>
							<td>Jl. Galar I/22 RT.001 RW.016 <br> Kelurahan Telogosari Kulon, Kec. Pedurungan, Semarang 50196</td>
						</tr>
						<tr>
							<td>Alamat Rumah Sesudah Pensiun</td>
							<td>:</td>
							<td>Jl. Galar I/22 RT.001 RW.016 <br> Kelurahan Telogosari Kulon, Kec. Pedurungan, Semarang 50196</td>
						</tr>
					</table>
				</div>
				<div style="margin-left:50px; margin-top:30px; font-size:12px;">
					<p>Dengan ini menerangkan mempunyai tanggungan keluarga sebagai berikut :</p>
				</div>
				<div style="margin-left:50px; margin-top:20px; font-size:12px;">
					<table class="tabel" border="1px"  >
						<tr>
							<th>No. Urut</th>
							<th>Nama</th>
							<th>Hubungan Keluarga</th>
							<th>Tgl Lahir</th>
							<th>Pekerjaan / Sekolah</th>
							<th>Tanggal Nikah</th>
							<th>Keterangan</th>
						</tr>
						<tr align="center" style="font-size:7px;">
							<td>1</td>
							<td>2</td>
							<td>3</td>
							<td>4</td>
							<td>5</td>
							<td>6</td>
							<td>7</td>
						</tr>
						<tr align="center">
							<td>1</td>
							<td>Suratmi</td>
							<td>Istri</td>
							<td>10-10-1962</td>
							<td>-</td>
							<td>14-09-1984</td>
							<td>-</td>
						</tr>
					</table>
				</div>
				
				<div style="float:right; margin-left:500px; margin-top:30px; font-size:12px;">
					<p>Semarang, 29 Mei 2017</p>
					<br>
					<br>
					<p><u>Syamsudin Suryadi</u></p>
				</div>

				<div style="float:right; margin-left:300px; font-size:14px; margin-top:40px;">
					<p>Disahkan oleh,</p>
				</div>

				<div style=" margin-left:50px; font-size:12px; margin-top:40px;">
					<p>Kepala Kelurahan</p>
					<p style="margin-top:-10px;">LURAH TELOGOSARI KULON</p>
					<br>
					<br>
					<p>EKO YUNIARTO, S.IP .MM</p>
					<p  style="margin-top:-10px;">(NIP. . . . . . . . . . . . . . . . . )</p>
				</div>
				<div style=" margin-left:500px; font-size:12px; margin-top:-120px;">
					<p>Kepala Kecamatan</p>
					<p style="margin-top:-10px;">A.n. CAMAT PEDURUNGAN</p>
					<br>
					<br>
					<p>YULIARTO, SH</p>
					<p  style="margin-top:-10px;">(NIP. . . . . . . . . . . . . . . . . )</p>
				</div>

				';
$content 		.= '</page>';



	$content 	.= '<page style="font-size: 16px; " orientation="portrait" format="A4" >
						<div style="width:20%;">
							<img src="assets/images/logo2.gif" style="margin-left:20px; height:100px; width:100px;">
						</div>
						<div style="width:80%; margin-left:135px;">
							<p align="center" style="margin-top:-80px; font-size: 14px;">KEMENTRIAN RISET, TEKNOLOGI DAN PENDIDIKAN TINGGI</p>
							<p align="center" style="margin-top:-10px; font-size: 14px;"><b>POLITEKNIK NEGERI SEMARANG</b></p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">Jalan Prof. H. Soedarto, S.H. Tembalang, Semarang 50275, PO BOX 6199/SMS</p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">Telephone (024) 7473417, 7499586, Facsimile (024) 7472396</p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">http:/www.polines.ae.id, E-mail : sekretariat@polines.ae.id.</p>
						</div>
						';
	$content	.= 
				'
				<hr>
				<br>
				<div style=" font-size:14px;">
						<p align="center" style="margin-top:-10px; font-size: 14px;"><b>SURAT PERNYATAAN</b></p>
						<p align="center" style="margin-top:-10px; font-size: 14px;"><b>TIDAK PERNAH DIJATUHI HUKUMAN DISIPLIN</b></p>
						<p align="center" style="margin-top:-10px; font-size: 14px;"><b>TINGKAT SEDANG ATAU BERAT</b></p>
				</div>
				<hr>
				<div>
					<p align="center" style="font-size: 13px;">Nomor : 3488/PL4.7.1/KP/2017</p>
				</div>
				<div style="margin-left:50px; font-size:12px;">
					<p>Yang bertanda tangan dibawah ini :</p>
					<table>
						<tr>
							<td>Nama</td>
							<td>:</td>
							<td>Ir. Supriyadi, MT.</td>
						</tr>
						<tr>
							<td>NIP</td>
							<td>:</td>
							<td>19590906 198703 1 002</td>
						</tr>
						<tr>
							<td>Pangkat / Gol. dan Pangkat</td>
							<td>:</td>
							<td>Pembina Utama Muda, IV/c</td>
						</tr>
						<tr>
							<td>Jabatan</td>
							<td>:</td>
							<td>Direktur</td>
						</tr>
					</table>
				</div>
				<div style="margin-left:50px; margin-top:15px; font-size:12px;">
					<p>dengan ini menyatakan dengan sesungguhnya, bahwa Pegawai Negeri Sipil :</p>
				</div>
				<div style="margin-left:50px; margin-top:10px; font-size:12px;">
					<table>
						<tr>
							<td>Nama</td>
							<td>:</td>
							<td>Syamsudin Suryadi</td>
						</tr>
						<tr>
							<td>NIP</td>
							<td>:</td>
							<td>19600121 198902 1 001</td>
						</tr>
						<tr>
							<td>Pangkat / Gol. dan Pangkat</td>
							<td>:</td>
							<td>Penata, III/c</td>
						</tr>
						<tr>
							<td>Tempat/Tgl. Lahir</td>
							<td>:</td>
							<td>Semarang, 21 Januari 1960</td>
						</tr>
						<tr>
							<td>Jabatan</td>
							<td>:</td>
							<td>Pranata Labotatorium Pendidikan Penyelia</td>
						</tr>
						<tr>
							<td>Instansi</td>
							<td>:</td>
							<td>Politeknik Negeri Semarang</td>
						</tr>
					</table>
				</div>
				
				<div style="margin-left:50px; margin-top:15px; font-size:12px;">
					<p>dalam satu tahun terakhir <b>tidak pernah dijatuhi hukuman</b> disiplin tingkat sedang atau berat.</p>
				</div>

				<div style="margin-left:50px; margin-right:50px; margin-top:15px; font-size:12px;">
					<p>Demikian surat pernyataan ini saya buat dengan sesungguhnya dengan mengingat sumpah jabatan dan apabila dikemudian hari ternyata isi surat pernyataan ini tidak benar yang mengakibatkan kerugian negara, maka saya bersedia menanggung kerugian tersebut.</p>
				</div>

				<div style="float:right; margin-left:400px; margin-top:50px; font-size:12px;">
					<p>Semarang, 5 Juni 2017</p>
					<p style="margin-top:-10px;">Direktur</p>
					<br>
					<br>
					<p>Ir. Supriyadi, MT.</p>
					<p style="margin-top:-10px;">NIP. 19590906 198703 1 002 </p>
				</div>
				<div style="margin-left:50px; margin-top:15px; font-size:12px;">
					<p>Tembusan :</p>
					<p style="margin-top:-10px;">1. Wadir Bidang Umum dan Keuangan</p>
					<p style="margin-top:-10px;">2. Kajur Teknik Mesin</p>
					<p style="margin-top:-10px;">3. Kabag AKPK</p>
					<p style="margin-top:-10px;">4. Kabag Umum dan Keuangan</p>
					<p style="margin-top:-10px;">5. Kasubbag Kepegawaian</p>
				</div>
				';
$content 		.= '</page>';



	$content 	.= '<page style="font-size: 16px; " orientation="portrait" format="A4" >
						<div style="width:20%;">
							<img src="assets/images/logo2.gif" style="margin-left:20px; height:100px; width:100px;">
						</div>
						<div style="width:80%; margin-left:135px;">
							<p align="center" style="margin-top:-80px; font-size: 14px;">KEMENTRIAN RISET, TEKNOLOGI DAN PENDIDIKAN TINGGI</p>
							<p align="center" style="margin-top:-10px; font-size: 14px;"><b>POLITEKNIK NEGERI SEMARANG</b></p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">Jalan Prof. H. Soedarto, S.H. Tembalang, Semarang 50275, PO BOX 6199/SMS</p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">Telephone (024) 7473417, 7499586, Facsimile (024) 7472396</p>
							<p align="center" style="margin-top:-10px; font-size: 12px;">http:/www.polines.ae.id, E-mail : sekretariat@polines.ae.id.</p>
						</div>
						';
	$content	.= 
				'
				<hr>
				<div style="margin-left:600px; margin-top:0px; font-size:12px;">
				' . $row->tanggal_pensiun . '
				</div>
				<div style="margin-left:50px; margin-top:-20px; font-size:12px;">
					<table>
						<tr>
							<td>Nomor</td>
							<td>:</td>
							<td>' . $row->nomor_pensiun . '</td>
						</tr>
						<tr>
							<td>Lampiran</td>
							<td>:</td>
							<td>1 (satu) bandel</td>
						</tr>
						<tr>
							<td>Perihal</td>
							<td>:</td>
							<td><b>Usul Pensiun (BUP)</b></td>
						</tr>
					</table>
				</div>
				<div style="margin-left:50px; margin-top:20px; font-size:12px;">
					<p style="margin-top:-8px;">' . $row->tujuan_pensiun . '</p>
					
				</div>
				<div style="margin-left:50px; margin-right:50px; margin-top:20px; font-size:12px;">
					<p style="margin-top:-8px;">' . $row->pembukaan_pensiun . '</p>
				</div>

				<div style="margin-left:50px; margin-top:20px; font-size:12px;">
					<table>
						<tr>
							<td>Nama</td>
							<td>:</td>
							<td>' . $row->nm_pegawai . '</td>
						</tr>
						<tr>
							<td>NIP</td>
							<td>:</td>
							<td>' . $row->nip_baru . '</td>
						</tr>
						<tr>
							<td>Tempat / Tgl. Lahir</td>
							<td>:</td>
							<td>' . $row->tempat_lahir . ', ' . $row->tanggal_lahir . '</td>
						</tr>
						<tr>
							<td>Pangkat / Gol. dan Pangkat</td>
							<td>:</td>
							<td>' . $row->pangkat_pensiun . '</td>
						</tr>
						<tr>
							<td>Jabatan</td>
							<td>:</td>
							<td>' . $row->jabatan_pensiun . '</td>
						</tr>
						<tr>
							<td>Alamat</td>
							<td>:</td>
							<td>' . $row->alamat_jalan . '</td>
						</tr>
					</table>
				</div>

				<div style="margin-left:50px; margin-right:50px; margin-top:20px; font-size:12px;">
					<p style="margin-top:-8px;">Sebagai bagian pertimbangan, bersama ini pula kami lampirkan :</p>
				</div>

				<div style="margin-left:50px; margin-right:50px; margin-top:0px; font-size:12px;">
					<table>
						<tr>
							<td>' . $row->lampiran_pensiun . '</td>
						</tr>
					</table>
				</div>

				<div style="margin-left:50px; margin-right:50px; margin-top:0px; font-size:12px;">
					<p>' . $row->penutup_pensiun . '</p>
				</div>


				<div style="float:right; margin-left:400px; margin-top:0px; font-size:12px;">
					<p>Semarang, 5 Juni 2017</p>
					<p style="margin-top:-10px;">Direktur</p>
					<br>
					<br>
					<p>Ir. Supriyadi, MT.</p>
					<p style="margin-top:-10px;">NIP. 19590906 198703 1 002 </p>
				</div>
				<div style="margin-left:50px; margin-top:0px; font-size:12px;">
					<p>Tembusan :</p>
					<table>
						<tr>
							<td>' . $row->tembusan_pensiun . '</td>
						</tr>
					</table>
				</div>

				';
$content 		.= '</page>';


require_once('assets/html2pdf/html2pdf.class.php');
$html2pdf 	= new HTML2PDF('P','A4','en');
$html2pdf->WriteHTML($content);
$html2pdf->Output('cetak_pensiun.pdf');
} ?>